function [Alternative_temp,TEMP_VV,TEMP_AA,TEMP_BB,TEMP_Total]= State1_B0(Alternative,No_request,A,B,Request_lift_intime,Request_shuttle_intime,t_l,t_v)
% ����ѡ��Alternative������չ��VΪAlternative��Ŀ��ֵ��
%  Alternative = [1;2];
%  No_request = 5;
% Request_lift_intime = [1,2,3,4,6];
% Request_shuttle_intime = [2,4,7,8,11];  
% V =[3,6];
% A = [2,0,0,0,0;
%     0,4,0,0,0];
% B = [3,0,0,0,0;
%     0,6,0,0,0];
% t_l=0;
% t_v=0;
Alternative_temp = [];
TEMP_VV = [];
TEMP_AA = [];
TEMP_BB = [];
TEMP_Total= [];
for i = 1: size(Alternative,1)
    set = FindSet1(1:No_request,Alternative(i,:)); %�ҵ�����Alternative����չ��state
    Alternative_temp = [Alternative_temp;set];
     for j = 1: size(set,1)        
        f(:,1) = (1:No_request)';
        f(:,2) = A(i,:)';
        f(:,3) = B(i,:)';
        ff =  Cycletime_B0(set(j,:),setdiff(set(j,:),Alternative(i,:)),Request_lift_intime,Request_shuttle_intime,f,t_l,t_v);    
         VV(j) = max(ff(:,3));
          AA(j,:) = ff(:,2);
          BB(j,:) = ff(:,3);
          LB_value = -1*LB(set(j,:),No_request,Request_lift_intime);
          Total(j)=VV(j)+LB_value;
    end
      TEMP_VV = [TEMP_VV;VV'];
      TEMP_AA = [TEMP_AA;AA];
      TEMP_BB = [TEMP_BB;BB];
      TEMP_Total = [TEMP_Total;Total'];
      clear VV LB Total
end
