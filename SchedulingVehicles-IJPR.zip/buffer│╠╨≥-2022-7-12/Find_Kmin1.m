function [SubAlternative,V_new,AA_new,BB_new] = Find_Kmin1(Alternative,VV,AA,BB,Total,m)
% Alternative =[1 ,    3 ,    5;
%      1   ,  3  ,   8;
%      1  ,   3   , 10;
%      1   ,  5  ,   8;
%      1   ,  5  ,  10];
% VV =[  38;33; 16; 56;  42];
% Total =[209;213; 215; 210; 212];
% 
% AA  = [10,0,0,0;
%     0,0,0,5;
%     0,0,4,0;
%     0,0,12,0;
%     4,0,0,0];
%  m=2;
 
 
% ����ѡ���Alternative������Totalֵѡ��ǰm��ѡ��������Ӧ��VVֵ
[~,d]=sort(Total);

if size(Alternative,2)~=1
    SubAlternative = Alternative(d(1:min(m,size(Alternative,1))),:);
else
    SubAlternative = Alternative(d(1:min(m,size(Alternative,1))));
end
V_new = VV(d(1:min(m,size(Alternative,1))));
AA_new = AA(d(1:min(m,size(Alternative,1))),:);
BB_new = BB(d(1:min(m,size(Alternative,1))),:);




