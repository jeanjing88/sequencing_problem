
clear all
clc
% rng(2)
No_tier = 12;      %number of tiers
No_location =450;   %number of storage location per aisle
No_request =10;     %���������
for id = 1:5
id
X = 1:No_tier;
Y = 1:No_location;

Request_tier = sort(X(randi(numel(X),No_request,1)));   %���ɵ�aisle index
Request_location = Y(randi(numel(Y),No_request,1)); %���ɵ� location  index
Request_location1 = [];
Request_location_LB = [];
for i = 1:No_tier
  temp22 = find(Request_tier==i);   % ÿһ����������
   H{i} = Request_location(temp22);   % ÿһ�����������location
  temp33 = H{i};
  Request_location1 = [Request_location1, sort(temp33)];
end
Request_location = Request_location1;   %��Request_location������������

for i = 1:No_tier
  temp44 = find(Request_tier==i);   % ÿһ����������
   H{i} = Request_location(temp44);   % ÿһ�����������location
  temp55 = H{i};
Request_location_LB = [Request_location_LB,cumsum(temp55)];
end

D_1 = 1;  %ÿ��location�Ŀ���
D_2 = 0.6;  %ÿ��ĸ߶�
v_v = 4;  %shuttle�ٶ�
v_l = 3;  %lift�ٶ�
t_v = 3;% Time for the vehicle to pick up a load from the storage location or dropoff a load at the buffer.
t_l =5; %Time for the lift to pick up a load from the buffer or drop off a load at the I/O point.
 
Request_shuttle_intime  = 2*D_1*Request_location/v_v+2*t_v;
Request_lift_intime = (Request_tier-1)*D_2/v_l;






%% ���ñ�������ʽ�����Ž�
%sequence_total = perms(1:No_request);  % ��һ�������1����ɣ���3�������2����ɣ���������
% makespan00 = zeros(1,size(sequence_total,1));
% makespan11 = zeros(1,size(sequence_total,1));
% makespanMM = zeros(1,size(sequence_total,1));
 % for oo = 1:size(sequence_total,1)
 %sequence = sequence_total(oo,:);
% % 1. buffer����0 
% makespan00(oo) = Given_sequence_buffer0(sequence,Request_tier,Request_location,No_request);
% %% 2. buffer����1
 %makespan11(oo) = Given_sequence_buffer1(sequence,Request_tier,Request_location,No_request);
%  %% 3. buffer��������
% makespanMM(oo) = Given_sequence_buffer1(sequence,Request_tier,Request_location,No_request);
 % end
% makespan0 = min(makespan00)
% makespan1 = min(makespan11)
%makespanM = min(makespanMM)

C = zeros(1,No_request);
f(:,1) = (1:No_request)';
f(:,2) = zeros(1,No_request)';
f(:,3) = zeros(1,No_request)';
%% ���ö�̬�滮�ķ���������Ž�
%  tic
% % % ��һ�׶� 

% %F��ʾǰk��cycle�����ʱ��
% F = 0;
%  for i = 1:No_request
% V{1,i} = Cycletime(i,i,Request_lift_intime,Request_shuttle_intime,f,t_l,t_v);
%  end
% 
% % Stage2��No_request-1
% for k = 2:No_request    %��ʾ��2��stage�����һ��stage
%     subset = nchoosek(1:No_request,k);
%     for i = 1:size(subset,1)
%         set_i = subset(i,:);
%         for j = 1:length(set_i)
%             location = FindLocation1(1:No_request,set_i,set_i(j)); %    M=[1,2,3,6,8]; %m=[2,3,6]; k=[6];  ȷ��[2,3]��������Ԫ���Ӽ��е�λ��
%             tempp = Cycletime(set_i,set_i(j),Request_lift_intime,Request_shuttle_intime,V{k-1,location},t_l,t_v);
%             ff(j) = max(tempp(:,3));
%             VV{j} = tempp;
%         end
%         [~,index] = min(ff);
%         V{k,i} =  VV{index};
%         clear ff VV
%     end
% end
% temppp = V{end,1};
% makespan_DP = max(temppp(:,3))
%  toc
%% ����beam search�ķ����������
Alternative = (1:No_request)';
VV = zeros(1,No_request); % ��ǰstate��ֵ
Total = zeros(1,No_request); %��ǰstate��ֵ���ϵ�ǰlower bound��ֵ

% ���ڵ�һ���׶�

 for i = 1:No_request
temp_BS = Cycletime(i,i,Request_lift_intime,Request_shuttle_intime,f,t_l,t_v);
VV(1,i) = max(temp_BS(:,3));
AA(i,:) = temp_BS(:,2); 
BB(i,:) = temp_BS(:,3); 
Total(i) = VV(1,i)+LB(i,No_request,Request_tier);
 end

for j = 1:No_request-1
[Alternative_New,VV_new,AA_new,BB_new] = Find_Kmin1(Alternative,VV,AA,BB,Total,20);
[Alternative,VV,AA,BB,Total]= State1(Alternative_New,No_request,AA_new,BB_new,Request_lift_intime,Request_shuttle_intime,t_l,t_v);
end
makespan_BS = min(VV);
C_BS(id)=makespan_BS;


%% NN
dis = 10000*ones(No_request,No_request);
for i = 1:No_request
  for j = 1:No_request
      if i~=j
dis(i,j) = distance(i,j,Request_shuttle_intime,Request_lift_intime);
      end
  end
end

[x, y] = find(dis==min(min(dis)));
sequence_NN(1) =x(1);
sequence_NN(2) =y(1);
dis(x(1),y(1))=1000;
while 1
    [~,index_NN] =min(dis(:,sequence_NN(end))) ;
    dis(sequence_NN,index_NN)=1000;
    sequence_NN = [sequence_NN,index_NN];
    if length(sequence_NN)==No_request
        break
    end
end
makespan_NN = Given_sequence_buffer1(sequence_NN,Request_lift_intime,Request_shuttle_intime,No_request,t_l,t_v);
 C_NN(id)=makespan_NN;
clear dis sequence_NN


%  %% LB-1
%  
%  t_LB = Request_location_LB-Request_tier;
%  [~,sequence_LB] = sort(t_LB);
%  makespan_LB1 = Given_sequence_bufferM(sequence_LB,Request_lift_intime,Request_shuttle_intime,No_request,t_l,t_v);
%  C_LB1(id)=makespan_LB1;
% %% LB-2
% makespan_LB2 = LB([],No_request,Request_lift_intime);
%  C_LB2(id) = makespan_LB2;

%% SPT_total�� p+d

 tt = Request_location+Request_tier;
 [~,sequence_SPT] = sort(tt);
makespan_SPT = Given_sequence_buffer1(sequence_SPT,Request_lift_intime,Request_shuttle_intime,No_request,t_l,t_v);
 C_SPT(id)=makespan_SPT;



%% p-d
 ttttt = Request_location-Request_tier;
 [~,sequence1] = sort(ttttt);
makespan_p_d = Given_sequence_buffer1(sequence1,Request_lift_intime,Request_shuttle_intime,No_request,t_l,t_v);
 C_p_d(id)=makespan_p_d;

%% p ����
[~,sequence_p_sheng] = sort(Request_location);
makespan_p_sheng = Given_sequence_buffer1(sequence_p_sheng,Request_lift_intime,Request_shuttle_intime,No_request,t_l,t_v);
C_p_sheng(id)=makespan_p_sheng;

%% p ����
[~,sequence_p_jiang] = sort(Request_location,2,'descend');
makespan_p_jiang = Given_sequence_buffer1(sequence_p_jiang,Request_lift_intime,Request_shuttle_intime,No_request,t_l,t_v);
 C_p_jiang(id)=makespan_p_jiang;

%% d ����
[~,sequence_d_sheng] = sort(Request_tier);
makespan_d_sheng = Given_sequence_buffer1(sequence_d_sheng,Request_lift_intime,Request_shuttle_intime,No_request,t_l,t_v);
 C_d_sheng(id)=makespan_d_sheng;

%% d ����
[~,sequence_d_jiang] = sort(Request_tier,2,'descend');
makespan_d_jiang = Given_sequence_buffer1(sequence_d_jiang,Request_lift_intime,Request_shuttle_intime,No_request,t_l,t_v);
 C_d_jiang(id)=makespan_d_jiang;
 %% FCFS
% 
 sequence_FCFS = randperm(No_request);
 
makespan_FCFS = Given_sequence_buffer1(sequence_FCFS,Request_lift_intime,Request_shuttle_intime,No_request,t_l,t_v);
  C_FCFS(id)=makespan_FCFS ;

%% Buffer = 0 

% 
% Alternative_B0 = (1:No_request)';
% VV_B0 = zeros(1,No_request); % ��ǰstate��ֵ
% Total_B0 = zeros(1,No_request); %��ǰstate��ֵ���ϵ�ǰlower bound��ֵ
% % ���ڵ�һ���׶�
% 
%  for i = 1:No_request
% temp_BS_B0 = Cycletime_B0(i,i,Request_lift_intime,Request_shuttle_intime,f,t_l,t_v);
% VV_B0(1,i) = max(temp_BS_B0(:,3));
% AA_B0(i,:) = temp_BS_B0(:,2); 
% BB_B0(i,:) = temp_BS_B0(:,3); 
% Total_B0(i) = VV_B0(1,i)+LB(i,No_request,Request_tier);
%  end
% 
% for j = 1:No_request-1
% [Alternative_New_B0,VV_new_B0,AA_new_B0,BB_new_B0] = Find_Kmin1(Alternative_B0,VV_B0,AA_B0,BB_B0,Total_B0,4);
% [Alternative_B0,VV_B0,AA_B0,BB_B0,Total_B0]= State1_B0(Alternative_New_B0,No_request,AA_new_B0,BB_new_B0,Request_lift_intime,Request_shuttle_intime,t_l,t_v);
% tempppp{j} = Alternative_New_B0(1,:);
% end
% tempppp{1} = tempppp{2}(2);
% tempppp{No_request} = 1:No_request;
% sequence_BS(1) = tempppp{1};
% for j = 2:No_request
%     j
% sequence_BS(j) = setdiff(tempppp{j},tempppp{j-1});    
% end
% 
% clear tempppp
% 
% makespan_BS_0dairu1(id) = Given_sequence_buffer1(sequence_BS,Request_lift_intime,Request_shuttle_intime,No_request,t_l,t_v);
% 
%  makespan_BS_B0 = min(VV_B0);
% C_BS_B0(id)=makespan_BS_B0 ;
% %%%����buffer0  BS��Ӧ��sequence���ٴ��뵽buffer1�ı���ʽ��
% 
 end

% (makespan_BS_0dairu1- C_BS)./makespan_BS_0dairu1


%  (C_BS_B0- C_BS)./(C_BS_B0)
gap_NN=(C_NN- C_BS)./(C_NN);
 gap_FCFS=(C_FCFS- C_BS)./(C_FCFS);
%  C_NN;
%   C_FCFS;
% C_LB1;
% C_LB2;

 %Gap_p_d=(C_p_d- C_BS)./C_p_d
% Gap_d_sheng=(C_d_sheng- C_BS)./C_d_sheng
% Gap_d_jiang=(C_d_jiang- C_BS)./C_d_jiang
% Gap_p_sheng=(C_p_sheng- C_BS)./C_p_sheng
% Gap_p_jiang=(C_p_jiang- C_BS)./C_p_jiang


( C_SPT- C_BS)./ C_SPT










%% CPLEX 

% %t_1(i,j)��lift��tier of request i��I/O���ͷ������ٵ�tier of request j��ʱ��
% t_1 = zeros(No_request,No_request);
% for i = 1:No_request
%     for j = 1:No_request
%         t_1(i,j) = D_2*(Request_tier(i)+Request_tier(j)-2)/v_l+2*t_l;
%     end
% end
% 
% %t_2(i)��lift��tier of request i��I/O���ͷ������ʱ��
% for i = 1:No_request
% t_2(i) = D_2*(Request_tier(i)-1)/v_l+2*t_l;
% end
% 
% 
% %p(i)����i��������ˮƽ�����ϵ����ʱ��
% p = 2*D_1*Request_location/v_v+2*t_v;
% 
% % a(i,j) =1 ��� i��j��ͬһtier
% a = zeros(No_request,No_request);
% for i = 1:No_request
%     for j = 1:No_request
%           if Request_tier(i)==Request_tier(j)
%               a(i,j)=1;
%           else
%               a(i,j)=0;
%           end        
%     end
% end
% 
% % �ҵ�������Ĳ������Լ���Ӧ����������
% uniq_tier = unique(Request_tier);
% H = length(uniq_tier);   %������Ĳ���
% 
% No_request_per_tier = zeros(1,H);  %��Ӧ����������
% for h = 1:H
%   No_request_per_tier(h) = length(find(Request_tier==uniq_tier(h)));
% end
% 
% % һ������������
% u = max(No_request_per_tier);
% 
% %ȷ�������tier�Ĺ�ϵ
%  Tier = [];
%  for i = 1:length(No_request_per_tier)
%      Tier = [ Tier,i*ones(1,No_request_per_tier(i))];% ���ж�����i����tier
%  end
% Request_index = 1:No_request;
% Request_Tier_relationship = [Request_index', Tier'];
%  
% Request_tier1 = cell(1,H);
% NoRequest_tier = cell(1,H);
% for h = 1:H 
% Request_tier1{h} = find(Request_Tier_relationship(:,2)==h)'; 
% NoRequest_tier{h} = 1:No_request_per_tier(h);  %ÿһ��������ǣ����� �ò���3��������ôNoRequest_tier=[1,2,3]
% end
% 
% clear ss y z t_3 c C
% 
% y = binvar(No_request,No_request,'full');
% z = binvar(No_request,u,'full');
% t_3 = sdpvar(1,No_request,'full');
% c = sdpvar(No_request,u,'full');
% 
% C = [];
% 
% for m = 1:No_request
%     C = [C,sum(y(:,m))==1];
% end
% 
% for i = 1:No_request
%     C = [C,sum(y(i,:))==1];
% end
% 
% for i = 1:No_request
%     C = [C,sum(z(i,:))==1];
% end
%   
% for h = 1:H
%     tempp = NoRequest_tier{h};
%     C= [C, sum(z(Request_tier1{h},tempp))==1];
% end
% 
% for i = 1:No_request
%     for j = 1:No_request
%         for m = 1:No_request
%             for w = 1:No_request
%                     for q = 1:u
%                         for b = 1:u
%                             if a(i,j)==1 && i~=j
%                                 C = [C,(m-w)*(b-q) <= -0.00001+500*(4-y(i,m)-y(j,w)-z(i,q)-z(j,b))];
%                             end
%                         end
%                     end
%             end
%         end
%     end
% end
% 
% % z֮��Ĺ�ϵ
% % ��һ������
% for i = 1:No_request
%         C = [C,p(i)+t_v <= c(i,1)+200*(1-z(i,1))];
% end
% 
% % ʣ������  ֻ��Ҫ�ҵ��ж���1������Ĳ�
% for i = 1:No_request
%     for  j = 1:No_request
%         for q = 2:u
%             for m =1:No_request
%                 if a(i,j)==1 && i~=j
%                     C = [C, max(t_3(m),p(j)+c(i,q-1))<=c(j,q)+200*(3-z(i,q-1)-z(j,q)-y(i,m))];
%                 end
%             end
%         end
%     end
% end
% 
% % y֮��Ĺ�ϵ
% % ��һ������
% for i = 1:No_request
%         C = [C,  c(i,1)<= t_3(1)+200*(2-y(i,1)-z(i,1))];
%          C = [C,  t_2(i)<= t_3(1)+200*(2-y(i,1)-z(i,1))];
% end
% 
% % ʣ������
% 
% for  i = 1:No_request
%     for j = 1:No_request
%         for m = 2:No_request
%             C = [C, t_3(m-1)+t_1(i,j) <= t_3(m)+200*(2-y(i,m-1)-y(j,m))];                   
%         end
%     end
% end
% 
% for j = 1:No_request
%         for m = 2:No_request
%             for q = 1:u
%                 C = [C, c(j,q) <= t_3(m)+200*(2-y(j,m)-z(j,q))];
%             end
%         end
% end
% 
% % Ŀ�꺯��
% ss = t_3(No_request);
% for i = 1:No_request   
%     ss = ss + t_2(i)*y(i,No_request);
% end
% ops = sdpsettings('verbose',0,'solver','lpsolve');
% result = optimize(C,ss);
% result.solvertime;
% makespan_CPLEX = value(ss)





