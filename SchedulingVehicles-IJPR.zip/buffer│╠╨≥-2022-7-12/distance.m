function dis = distance(request_i,request_j,Request_shuttle_intime,Request_lift_intime)


%Request_shuttle_intime = [2,4,4,10]
%Request_lift_intime = [5,7,9,11];

if Request_lift_intime(request_i)==Request_lift_intime(request_j)
    dis = abs(Request_shuttle_intime(request_i)-Request_shuttle_intime(request_j));
    
else
   dis = Request_shuttle_intime(request_i)+Request_shuttle_intime(request_j)+abs(Request_lift_intime(request_i)-Request_lift_intime(request_j));
    
    
end
    


